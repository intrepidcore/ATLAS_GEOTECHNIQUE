Atlas Géotechnique Togo - Export QGIS
=====================================

Paramètre : Nombre de sondages (n_sondages)
Unité : 
Type de carte : choropleth

Filtres appliqués :
- Région (ADM1) : Maritime
- Préfecture (ADM2) : Toutes
- Commune (ADM3) : Toutes
- Sondages minimum : Aucun

Instructions :
1. Dans QGIS, ajouter la couche "mailles_thematique.geojson"
2. Clic droit sur la couche > Propriétés > Symbologie
3. Charger le style : Cliquer sur "Style" > "Charger le style" > Sélectionner "style.qml"

Classes :
  - Classe 0 : <= 1.0 (#f7fbff)
  - Classe 1 : 1.0 - 2.0 (#6baed6)
  - Classe 2 : > 2.0 (#08306b)

Généré le : 2025-12-15 05:34:45 UTC
