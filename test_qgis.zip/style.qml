<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.28" styleCategories="AllStyleCategories">
  <renderer-v2 type="categorizedSymbol" attr="class_idx" symbollevels="0" enableorderby="0">
    <categories>
        <category symbol="0" value="0" label="<= 1.0" render="true"/>
        <category symbol="1" value="1" label="1.0 - 2.0" render="true"/>
        <category symbol="2" value="2" label="> 2.0" render="true"/>
    </categories>
    <symbols>
        <symbol name="0" type="fill" clip_to_extent="1" force_rhr="0" alpha="0.8">
          <layer pass="0" class="SimpleFill" enabled="1" locked="0">
            <prop k="color" v="247,251,255,200"/>
            <prop k="style" v="solid"/>
            <prop k="outline_color" v="35,35,35,255"/>
            <prop k="outline_style" v="solid"/>
            <prop k="outline_width" v="0.26"/>
          </layer>
        </symbol>
        <symbol name="1" type="fill" clip_to_extent="1" force_rhr="0" alpha="0.8">
          <layer pass="0" class="SimpleFill" enabled="1" locked="0">
            <prop k="color" v="107,174,214,200"/>
            <prop k="style" v="solid"/>
            <prop k="outline_color" v="35,35,35,255"/>
            <prop k="outline_style" v="solid"/>
            <prop k="outline_width" v="0.26"/>
          </layer>
        </symbol>
        <symbol name="2" type="fill" clip_to_extent="1" force_rhr="0" alpha="0.8">
          <layer pass="0" class="SimpleFill" enabled="1" locked="0">
            <prop k="color" v="8,48,107,200"/>
            <prop k="style" v="solid"/>
            <prop k="outline_color" v="35,35,35,255"/>
            <prop k="outline_style" v="solid"/>
            <prop k="outline_width" v="0.26"/>
          </layer>
        </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fieldName="class_label" fontSize="8" fontFamily="Sans Serif"/>
    </settings>
  </labeling>
</qgis>
